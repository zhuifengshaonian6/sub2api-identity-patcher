"use strict";

const assert = require("assert");
const {
  analyzeAccounts,
  patchAccounts,
  buildOutputName,
} = require("../patcher-core");

function makeExport(count, sharedAccountId = "workspace-shared") {
  return {
    exported_at: "2026-05-29T00:00:00.000Z",
    proxies: [],
    accounts: Array.from({ length: count }, (_, index) => ({
      name: `user${index + 1}@example.com`,
      platform: "openai",
      type: "oauth",
      credentials: {
        chatgpt_account_id: sharedAccountId,
        chatgpt_user_id: `user-${index + 1}`,
        email: `user${index + 1}@example.com`,
      },
      extra: {
        email: `user${index + 1}@example.com`,
      },
    })),
  };
}

function assertPatchesCount(count) {
  const data = makeExport(count);
  const before = analyzeAccounts(data.accounts);
  const stats = patchAccounts(data.accounts, true);
  const after = analyzeAccounts(data.accounts);
  const patchedIds = new Set(data.accounts.map((account) => account.credentials.chatgpt_account_id));
  const originalIds = new Set(data.accounts.map((account) => account.extra.original_chatgpt_account_id));

  assert.equal(before.accountCount, count);
  assert.equal(before.uniqueAccountIds, count > 0 ? 1 : 0);
  assert.equal(before.uniqueUserIds, count);
  assert.equal(before.patchable, count);
  assert.equal(stats.patched, count);
  assert.equal(stats.skipped, 0);
  assert.equal(after.uniqueAccountIds, count);
  assert.equal(after.patchable, 0);
  assert.equal(patchedIds.size, count);
  assert.equal(originalIds.size, count > 0 ? 1 : 0);
}

for (let count = 0; count <= 300; count += 37) {
  assertPatchesCount(count);
}

assertPatchesCount(1024);

{
  const data = makeExport(2);
  data.accounts[1].credentials.chatgpt_user_id = "";
  const stats = patchAccounts(data.accounts, true);
  assert.deepEqual(stats, { patched: 1, skipped: 1 });
  assert.equal(data.accounts[0].credentials.chatgpt_account_id, "user-1");
  assert.equal(data.accounts[1].credentials.chatgpt_account_id, "workspace-shared");
}

assert.equal(buildOutputName("gpt_sub2api_abc.json"), "gpt_sub2api_abc_user_identity_import.json");

console.log("patcher-core tests passed");
